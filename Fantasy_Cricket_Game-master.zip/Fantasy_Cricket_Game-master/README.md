# Fantasy_Cricket_Game
Fantasy Cricket Game is the final project given in the Programming with Python course of Internshala.
